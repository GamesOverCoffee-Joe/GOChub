<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors City Props" tilewidth="16" tileheight="16" tilecount="7168" columns="32">
 <image source="../images/exteriors/3_City_Props_16x16.png" width="512" height="3584"/>
</tileset>
