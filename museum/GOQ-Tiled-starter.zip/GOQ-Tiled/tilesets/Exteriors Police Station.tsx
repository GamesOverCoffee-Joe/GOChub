<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Police Station" tilewidth="16" tileheight="16" tilecount="2208" columns="32">
 <image source="../images/exteriors/15_Police_Station_16x16.png" width="512" height="1104"/>
</tileset>
