<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Subway and Train Station" tilewidth="16" tileheight="16" tilecount="5920" columns="32">
 <image source="../images/exteriors/20_Subway_and_Train_Station_16x16.png" width="512" height="2960"/>
</tileset>
