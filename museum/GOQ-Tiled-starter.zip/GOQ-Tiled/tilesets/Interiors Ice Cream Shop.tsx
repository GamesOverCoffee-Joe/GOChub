<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors Ice Cream Shop" tilewidth="16" tileheight="16" tilecount="272" columns="16">
 <image source="../images/interiors/24_Ice_Cream_Shop.png" width="256" height="272"/>
</tileset>
