<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Hotel and Hospital" tilewidth="16" tileheight="16" tilecount="1984" columns="32">
 <image source="../images/exteriors/12_Hotel_and_Hospital_16x16.png" width="512" height="992"/>
</tileset>
