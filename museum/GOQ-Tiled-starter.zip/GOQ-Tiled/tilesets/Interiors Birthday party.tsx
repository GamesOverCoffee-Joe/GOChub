<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors Birthday party" tilewidth="16" tileheight="16" tilecount="84" columns="12">
 <image source="../images/interiors/10_Birthday_party_16x16.png" width="192" height="112"/>
</tileset>
