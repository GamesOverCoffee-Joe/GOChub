<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Terrains and Fences" tilewidth="16" tileheight="16" tilecount="2368" columns="32">
 <image source="../images/exteriors/1_Terrains_and_Fences_16x16.png" width="512" height="1184"/>
</tileset>
