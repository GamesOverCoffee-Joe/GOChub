<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Shopping Center and Markets" tilewidth="16" tileheight="16" tilecount="2176" columns="32">
 <image source="../images/exteriors/9_Shopping_Center_and_Markets_16x16.png" width="512" height="1088"/>
</tileset>
