<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Generic Buildings" tilewidth="16" tileheight="16" tilecount="6400" columns="32">
 <image source="../images/exteriors/4_Generic_Buildings_16x16.png" width="512" height="3200"/>
</tileset>
