<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors Museum" tilewidth="16" tileheight="16" tilecount="1952" columns="16">
 <image source="../images/interiors/22_Museum.png" width="256" height="1952"/>
</tileset>
