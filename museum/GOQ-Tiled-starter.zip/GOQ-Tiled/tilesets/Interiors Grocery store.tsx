<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors Grocery store" tilewidth="16" tileheight="16" tilecount="1248" columns="16">
 <image source="../images/interiors/16_Grocery_store_16x16.png" width="256" height="1248"/>
</tileset>
