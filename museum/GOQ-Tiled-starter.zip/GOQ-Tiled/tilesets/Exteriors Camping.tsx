<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Camping" tilewidth="16" tileheight="16" tilecount="5792" columns="32">
 <image source="../images/exteriors/11_Camping_16x16.png" width="512" height="2896"/>
</tileset>
