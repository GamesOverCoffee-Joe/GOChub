<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Floor Modular Buildings" tilewidth="16" tileheight="16" tilecount="8288" columns="32">
 <image source="../images/exteriors/5_Floor_Modular_Buildings_16x16.png" width="512" height="4144"/>
</tileset>
