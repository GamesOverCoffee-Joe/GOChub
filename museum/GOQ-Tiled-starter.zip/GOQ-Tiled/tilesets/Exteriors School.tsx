<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors School" tilewidth="16" tileheight="16" tilecount="3712" columns="32">
 <image source="../images/exteriors/13_School_16x16.png" width="512" height="1856"/>
</tileset>
