<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors MIlitary Base" tilewidth="16" tileheight="16" tilecount="9120" columns="32">
 <image source="../images/exteriors/23_MIlitary_Base_16x16.png" width="512" height="4575"/>
</tileset>
