<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors Kitchen" tilewidth="16" tileheight="16" tilecount="784" columns="16">
 <image source="../images/interiors/12_Kitchen_16x16.png" width="256" height="784"/>
</tileset>
