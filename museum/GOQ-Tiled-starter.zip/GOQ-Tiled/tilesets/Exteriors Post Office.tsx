<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Post Office" tilewidth="16" tileheight="16" tilecount="960" columns="32">
 <image source="../images/exteriors/22_Post_Office_16x16.png" width="512" height="480"/>
</tileset>
