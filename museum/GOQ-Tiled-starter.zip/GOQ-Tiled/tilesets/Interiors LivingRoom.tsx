<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors LivingRoom" tilewidth="16" tileheight="16" tilecount="720" columns="16">
 <image source="../images/interiors/2_LivingRoom_16x16.png" width="256" height="720"/>
</tileset>
