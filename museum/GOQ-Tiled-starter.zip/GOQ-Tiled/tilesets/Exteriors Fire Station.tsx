<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Fire Station" tilewidth="16" tileheight="16" tilecount="990" columns="33">
 <image source="../images/exteriors/18_Fire_Station_16x16.png" width="528" height="480"/>
</tileset>
