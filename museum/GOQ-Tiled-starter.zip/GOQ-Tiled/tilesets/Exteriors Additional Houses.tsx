<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Exteriors Additional Houses" tilewidth="16" tileheight="16" tilecount="9856" columns="32">
 <image source="../images/exteriors/24_Additional_Houses_16x16.png" width="512" height="4928"/>
</tileset>
