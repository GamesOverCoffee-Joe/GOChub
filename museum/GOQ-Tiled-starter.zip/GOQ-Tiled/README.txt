GOQ Museum maps for Tiled

1. Open GOQ.tiled-project in Tiled (File > Open File or Project).
2. Open a room from maps/ (start with lobby.tmj).
3. The faded picture is the room as the game draws it now. Paint over it on the layers:
   Floor, Walls, Furniture, Details (all drawn under people), Above people (drawn over them).
4. Leave Logic empty for now.
5. Save. Keep the folders together (maps, tilesets, images, reference).
